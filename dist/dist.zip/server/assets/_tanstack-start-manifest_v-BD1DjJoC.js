//#region \0tanstack-start-manifest:v
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/site funeraria/site funeraria/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B8Q7NdZX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B8Q7NdZX.js"
		} }]
	},
	"/": {
		filePath: "C:/site funeraria/site funeraria/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BjKNS3_q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
